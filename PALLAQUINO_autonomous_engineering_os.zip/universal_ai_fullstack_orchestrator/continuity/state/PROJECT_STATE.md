# Project state

- Status: 0.3.2 released (`v0.3.2`) with the stack snapshot verified on 2026-10-14
- Version: 0.3.2 (patch over 0.3.0, Phase 1 of the v0.3 roadmap)
- Updated: 2026-10-14
- Agents: 59 (template contracts; v2 contracts planned)
- Skills: 90
- Modes: 11
- Technologies catalogued: 46 (baseline snapshot verified 2026-10-14)
- Stack profiles: 6
- Domain packs: 7
- Pipeline stages: 32 base stages plus 14 conditional gates
- CLI commands: 17 (new: `security`, `identity`; new flags: `init --dry-run`, `validate --integrity-only`, `handoff --next-action/--missing/--unverified`)
- Confidence: high
