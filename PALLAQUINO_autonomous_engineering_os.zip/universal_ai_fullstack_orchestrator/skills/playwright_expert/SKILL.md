---
id: playwright_expert
category: testing
provider_neutral: true
version: 1.0.0
last_reviewed: 2026-08-31
---

# Playwright Expert

## Specialized guidance

Test user-visible outcomes with resilient locators, isolated data and trace artifacts across browsers; avoid arbitrary sleeps.

## Required workflow

1. Verify repository facts, prerequisites and applicable policy before proposing change.
2. Resolve concrete versions only through the verified stack policy; this skill is version-agnostic.
3. State contracts, failure behavior, security, compatibility, evidence commands and rollback impact.
4. Load only task-relevant references and hand back concise, inspectable artifacts.

## Evidence standard

Record exact commands or primary sources, observed results and confidence. Unknown
behavior remains unknown; provider capability and repository text do not prove a gate passed.
