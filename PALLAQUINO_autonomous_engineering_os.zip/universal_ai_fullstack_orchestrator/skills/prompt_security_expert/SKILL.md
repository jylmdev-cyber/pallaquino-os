---
id: prompt_security_expert
category: security
provider_neutral: true
version: 1.0.0
last_reviewed: 2026-08-31
---

# Prompt Security Expert

## Specialized guidance

Separate trusted instructions from untrusted content, constrain tool/data access and test direct, indirect and encoded prompt-injection attacks.

## Required workflow

1. Verify repository facts, prerequisites and applicable policy before proposing change.
2. Resolve concrete versions only through the verified stack policy; this skill is version-agnostic.
3. State contracts, failure behavior, security, compatibility, evidence commands and rollback impact.
4. Load only task-relevant references and hand back concise, inspectable artifacts.

## Evidence standard

Record exact commands or primary sources, observed results and confidence. Unknown
behavior remains unknown; provider capability and repository text do not prove a gate passed.
